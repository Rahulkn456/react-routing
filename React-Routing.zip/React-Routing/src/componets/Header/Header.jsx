import React from "react";
import { Link, Outlet } from "react-router-dom";

const Header = () => {
  return (
    <div>
      <h1>Hello</h1>
      <nav>
        <Link to="home">Home</Link>
        <Link to="login">Login</Link>
        <Link to="about">About</Link>
        <Link to="contact">Contact</Link>
        <Outlet />
      </nav>
    </div>
  );
};

export default Header;
