import React from "react";

const About = () => {
  return <h1>I am AboutPage</h1>;
};

export default About;
