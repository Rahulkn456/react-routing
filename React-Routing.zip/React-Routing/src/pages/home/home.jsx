import React from "react";

const Home = () => {
  return <h1>I am Home Page</h1>;
};

export default Home;
