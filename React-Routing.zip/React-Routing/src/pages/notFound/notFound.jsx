import React from "react";

const NotFound = () => {
  return <h1>404 Error</h1>;
};

export default NotFound;
